package io.prometheus.client.sample.mock;

/**
 * Created by zhengyunlong on 7/5/18.
 */
public class Request {
    public double size() {
        return 0;
    }
}
